﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01Test
{
    class NotPossibleException : Exception
    {
    }
}
