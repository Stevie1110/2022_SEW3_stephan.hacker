﻿using System;

namespace _2._1_Vorkommen
{
    class Program
    {
        static void Main(string[] args)
        {
            AnalyseText.analyse("IT ist ein Akronym und steht für Informationstechnologie. Zu IT-Services werden Dienstleistungen wie Installation, Beratung, Wartung, Test und Entwicklung gezählt. Fachkräftemangel herrscht vor allem im Bereich IT-Security", "IT");
        }
    }
}
