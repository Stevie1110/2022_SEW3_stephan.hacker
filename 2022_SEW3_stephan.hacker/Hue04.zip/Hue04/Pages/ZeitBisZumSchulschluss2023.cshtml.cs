using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hue04.Pages
{
    public class ZeitBisZumSchulschluss2023Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
